package org.example;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.geometry.VPos;

import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.text.TextAlignment;

import java.io.*;
import java.net.Socket;
import java.net.URL;

import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;


public class TCP_Client_Schedule_Controller implements Initializable {

    // Main Lecture Schedule at Client Side -- Arraylist of LectureController (MVC)
    private static List<LectureController> LectureSchedule = new ArrayList<>();

    @FXML
    private GridPane GridFullSchedule;

    @FXML
    private TableView<Lecture> LecturesScheduleTableView;
    @FXML
    private TableColumn<Lecture, String> DayColumn;
    @FXML
    private TableColumn<Lecture, String> TimeColumn;
    @FXML
    private TableColumn<Lecture, String> ModuleColumn;
    @FXML
    private TableColumn<Lecture, String> ProfessorColumn;
    @FXML
    private TableColumn<Lecture, String> RoomColumn;

    @FXML
    private TextField ModuleTextBox;
    @FXML
    private TextField ProfessorTextBox;
    @FXML
    private TextField RoomTextBox;

    @FXML
    private Button AddLectureButton;
    @FXML
    private Button RemoveLectureButton;
    @FXML
    private Button ConnectButton;
    @FXML
    private Button DisconnectButton;
    @FXML
    private Button DisplayFullScheduleButton;
    @FXML
    private Button UnavailableServiceButton;

    @FXML
    private ComboBox<String> TimeComboBox;
    @FXML
    private ComboBox<String> DayComboBox;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        // On Window initialize, Prepare the Columns in Table View
        DayColumn.setCellValueFactory(new PropertyValueFactory<Lecture, String>("day"));
        TimeColumn.setCellValueFactory(new PropertyValueFactory<Lecture, String>("time"));
        ModuleColumn.setCellValueFactory(new PropertyValueFactory<Lecture, String>("moduleCode"));
        ProfessorColumn.setCellValueFactory(new PropertyValueFactory<Lecture, String>("professor"));
        RoomColumn.setCellValueFactory(new PropertyValueFactory<Lecture, String>("roomId"));

        // On Window initialize, Fill Time Slot ComboBox and Day ComboBox
        TimeComboBox.setItems(FXCollections.observableArrayList("09:00-10:00", "10:00-11:00", "11:00-12:00", "12:00-13:00", "13:00-14:00", "14:00-15:00", "15:00-16:00", "16:00-17:00", "17:00-18:00"));
        DayComboBox.setItems(FXCollections.observableArrayList("Monday", "Tuesday", "Wednesday", "Thursday", "Friday"));

        // On Window initialize, Create new Empty Labels and add them to the Grid Pane
        PrepareGridPaneLabels();
    }

    //Flag to keep track of connection status
    private static boolean IsConnectedToServer = false;


    // This variable to keep the selected Lecture from Table View for later Deletion
    private static Lecture SelectedLecture;

    @FXML
    void rowClicked(MouseEvent event) {
        SelectedLecture = LecturesScheduleTableView.getSelectionModel().getSelectedItem(); //Keep the selected Lecture

        // To enable the remove button, should be connected to server and there is a selected lecture
        if (IsConnectedToServer && SelectedLecture != null) {
            RemoveLectureButton.setDisable(false); // Enable Remove Button
        } else {
            RemoveLectureButton.setDisable(true); // Disable Remove Button
        }
    }


    // This method to print LectureSchedule at console on Client side
    private static void printCurrentSchedule() {
        for (LectureController lecture : LectureSchedule)
            lecture.printLectureDetails();
    }

    // Networking Variables
    private static Socket socket;
    private static BufferedReader inputStream;
    private static PrintWriter outputStream;

    private static String serverAddress = "localhost";  // The server address (change if needed)
    private static int serverPort = 22345;


    // Method Connect() to connect to server - runs when pressing ConnectButton
    public void Connect(ActionEvent event) {
        System.out.println("\nConnecting to server ....");

        try {

            socket = new Socket(serverAddress, serverPort);
            inputStream = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            outputStream = new PrintWriter(socket.getOutputStream(), true);

            IsConnectedToServer = true;
            SetButtonsStatus();
            RefreshLectureTableViewFromServer();

        } catch (IOException e) {

            IsConnectedToServer = false;
            SetButtonsStatus();

            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }

    // Method Disconnect() to Disconnect from server - runs when pressing DisconnectButton
    public void Disconnect(ActionEvent event) throws IOException {

        // Log Stopping Connection at Client Console
        System.out.println("\nDisconnecting from server ....");
        System.out.println("\nsending STOP request to server");

        //Send STOP request to Server
        outputStream.println("STOP");

        // Now check for server response
        String ServerResponse = inputStream.readLine();

        if (ServerResponse.equals("TERMINATE")) {
            // Log server response at Client Console
            System.out.println("\nreceived TERMINATE response from server");

            ShowAlertBox("Server Terminated connection Successfully", Alert.AlertType.INFORMATION);

            // Now Close connection at client side
            try {
                if (outputStream != null) {
                    outputStream.flush();
                    outputStream.close();
                }

                if (inputStream != null) {
                    inputStream.close();
                }

                if (socket != null) {
                    socket.close();
                }

                IsConnectedToServer = false;
                SetButtonsStatus();

            } catch (IOException e) {

                //Reverse Buttons Status on Error
                IsConnectedToServer = true;
                SetButtonsStatus();
                e.printStackTrace();
            }

        } else {
            ShowAlertBox("Server Failed to Terminated connection !!", Alert.AlertType.ERROR);
        }

    }

    private void SetButtonsStatus() {
        if (IsConnectedToServer) {
            ConnectButton.setDisable(true);
            DisconnectButton.setDisable(false);
            AddLectureButton.setDisable(false);
            RemoveLectureButton.setDisable(true);
            DisplayFullScheduleButton.setDisable(false);
            UnavailableServiceButton.setDisable(false);
        } else {
            ConnectButton.setDisable(false);
            DisconnectButton.setDisable(true);
            AddLectureButton.setDisable(true);
            RemoveLectureButton.setDisable(true);
            DisplayFullScheduleButton.setDisable(true);
            UnavailableServiceButton.setDisable(true);
        }
    }


    public void addLecture(ActionEvent event) {

        // First Check if all required Lecture fields are Filled
        if (DayComboBox.getValue() != null && TimeComboBox.getValue() != null && !ModuleTextBox.getText().isEmpty() && !ProfessorTextBox.getText().isEmpty() && !RoomTextBox.getText().isEmpty()) {

            // Log request at Client Console
            System.out.println("\nSending to Server: " + "ADD LECTURE" + " " + DayComboBox.getValue() + "," + TimeComboBox.getValue() + "," + ModuleTextBox.getText() + "," + ProfessorTextBox.getText() + "," + RoomTextBox.getText());

            // Send Add request to server
            outputStream.println("ADD LECTURE" + " " + DayComboBox.getValue() + "," + TimeComboBox.getValue() + "," + ModuleTextBox.getText() + "," + ProfessorTextBox.getText() + "," + RoomTextBox.getText());

            // Now Check Server Response on the added Lecture
            try {

                String ServerResponse = inputStream.readLine();
                System.out.println("waiting for server response: " + ServerResponse);

                switch (ServerResponse) {
                    case "ADD_LECTURE_SUCCESS" -> {

                        ShowAlertBox("Lecture Added Successfully", Alert.AlertType.INFORMATION);

                        // Auto Refreshes Schedule after Add
                        RefreshLectureTableViewFromServer();
                    }

                    case "LECTURE_RESERVED_SAME_TIME_SLOT" ->
                            ShowAlertBox("Failed to add Lecture !! \nLecture of same course is occupied at the same time slot", Alert.AlertType.ERROR);

                    case "ROOM_OCCUPIED" ->
                            ShowAlertBox("Failed to add Lecture !! \nRoom is occupied at the same time slot", Alert.AlertType.ERROR);

                    case "MODULE_RESERVED_SAME_TIME_SLOT" ->
                            ShowAlertBox("Failed to add Lecture !! \nModule has a Lecture at the same time slot", Alert.AlertType.ERROR);
                    case "CANNOT_EXCEED_FIVE_MODULES" ->
                            ShowAlertBox("Failed to add Lecture !! \nTotal Modules in schedule cannot exceed 5", Alert.AlertType.ERROR);
                    case "PROFESSOR_HAS_LECTURE_SAME_TIME_SLOT" ->
                            ShowAlertBox("Failed to add Lecture !! \nProfessor Has a lecture at the same time slot", Alert.AlertType.ERROR);
                }


            } catch (IOException | ClassNotFoundException e) {
                throw new RuntimeException(e);
            }

        } else {

            ShowAlertBox("Please Check Entries, all fields are required !!", Alert.AlertType.WARNING);

        }
    }


    public void removeLecture(ActionEvent event) throws IOException, ClassNotFoundException {


        // Log request at Client Console
        System.out.println("\nSending to Server: " + "REMOVE LECTURE" + " " + SelectedLecture.getDay() + "," + SelectedLecture.getTime() + "," + SelectedLecture.getModuleCode() + "," + SelectedLecture.getProfessor() + "," + SelectedLecture.getRoomId());

        // Send Remove request to server
        outputStream.println("REMOVE LECTURE" + " " + SelectedLecture.getDay() + "," + SelectedLecture.getTime() + "," + SelectedLecture.getModuleCode() + "," + SelectedLecture.getProfessor() + "," + SelectedLecture.getRoomId());

        try {
            // Now Check Response from Server after Remove
            String ServerResponse = inputStream.readLine();

            if (ServerResponse.startsWith("REMOVE_LECTURE_SUCCESS")) {

                String[] dataArray = ServerResponse.split(",");

                String DayFreed = dataArray[1];
                String TimeFreed = dataArray[2];
                String RoomFreed = dataArray[3];

                ShowAlertBox("Lecture Removed Successfully\n Room " + RoomFreed + " is now available on " + DayFreed + " ( " + TimeFreed + " )", Alert.AlertType.INFORMATION);

                // Auto refresh Table View
                RefreshLectureTableViewFromServer();

            } else if (ServerResponse.equals("LECTURE_NOT_FOUND"))
                ShowAlertBox("Failed to remove Lecture, Lecture Not Found !!", Alert.AlertType.ERROR);


        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        //Make Delete Button Unavailable after delete, so the user can select another Lecture
        RemoveLectureButton.setDisable(true);

    }

    // This Method Shows a dynamic Alert Box
    public void ShowAlertBox(String Message, Alert.AlertType AlertType) {

        Alert alert = new Alert(AlertType);
        alert.setTitle("");
        alert.setContentText(Message);
        alert.setHeaderText(null);
        alert.showAndWait();
    }


    public void RefreshLectureTableViewFromServer() throws IOException, ClassNotFoundException {

        // First Get Latest Schedule from Server and update local ArrayList
        UpdateLocalArrayListFromServer();

        // Now Load Table View Data from Updated Local Lectures ArrayList
        LecturesScheduleTableView.getItems().clear();
        for (LectureController Lec : LectureSchedule) {
            LecturesScheduleTableView.getItems().add(Lec.getLecture());
        }
    }




    public void UpdateLocalArrayListFromServer() throws IOException, ClassNotFoundException {

        //First send the server the get lectures schedule request
        outputStream.println("DISPLAY SCHEDULE");

        // Log request locally on client console
        System.out.println("\nSending to Server: " + "DISPLAY SCHEDULE");


        // get the input stream from the same connected socket
        InputStream inputStreamObjects = socket.getInputStream();
        // create a DataInputStream for Objects so we can read data from it.
        ObjectInputStream objectInputStream = new ObjectInputStream(inputStreamObjects);

        // now get objects stream from server (with casting) and save it to local Lecture Schedule Array List
        LectureSchedule = (List<LectureController>) objectInputStream.readObject();

        // Log the updated schedule to Client console
        System.out.println("Received Schedule:");
        printCurrentSchedule();

    }
    public void EarlyLectures(ActionEvent event) throws IOException, ClassNotFoundException {
        //log
        System.out.println("\nSending to Server: " + "EARLY LECTURES");
        //send to server request
        outputStream.println("EARLY LECTURES");
    }


    public void RequestUnavailableService(ActionEvent event) throws IOException {

        // Log at Client Console this unavailable request for example (GET_COURSES_NAMES)
        System.out.println("\nSending to Server: " + "GET_COURSES_NAMES");

        // Send unavailable request to server (( example "GET_COURSES_NAMES" ))
        outputStream.println("GET_COURSES_NAMES");

        // Now get Server response
        String ServerResponse = inputStream.readLine();

        if (ServerResponse.equals("SERVICE_NOT_FOUND")) {

            ShowAlertBox("This service is not Available !! \n Connection will now close", Alert.AlertType.ERROR);

            // Now Close connection at client side
            try {
                if (outputStream != null) {
                    outputStream.flush();
                    outputStream.close();
                }

                if (inputStream != null) {
                    inputStream.close();
                }

                if (socket != null) {
                    socket.close();
                }

                IsConnectedToServer = false;
                SetButtonsStatus();

            } catch (IOException e) {

                //Reverse Buttons Status on Error
                IsConnectedToServer = true;
                SetButtonsStatus();
                e.printStackTrace();
            }
        } else {
            ShowAlertBox("Error in communicating with server !!", Alert.AlertType.ERROR);
        }

    }

    // This Method will Create new Empty Labels and add them to the Grid Pane
    public void PrepareGridPaneLabels() {

        for (int colIndex = 1; colIndex <= 5; colIndex++) {
            for (int rowIndex = 1; rowIndex <= 9; rowIndex++) {
                Label lbl = new Label();
                lbl.setText(""); //Start with Empty Labels

                lbl.setTextAlignment(TextAlignment.CENTER);
                lbl.setAlignment(Pos.CENTER);
                GridPane.setValignment(lbl, VPos.CENTER);
                GridPane.setHalignment(lbl, HPos.CENTER);

                GridFullSchedule.add(lbl, colIndex, rowIndex);
            }
        }
    }

    public void LoadLectureScheduleIntoGridPane() throws IOException, ClassNotFoundException {

        ClearLectureScheduleGridPane();
        RefreshLectureTableViewFromServer();

        for(LectureController lecture : LectureSchedule)
            SetLectureInCorrectPosition(lecture.getDay(),lecture.getTime(),lecture.getModuleCode(),lecture.getProfessor(),lecture.getRoomId());
    }


    private void SetLectureInCorrectPosition(String Day, String Time, String Module, String Professor, String Room) {

        // First Search all Grid Pane children and find the exact Label by (Day/Time)
        Label TheLabel = (Label)getNodeByRowCol(GetRowNumber(Time),GetColumnNumber(Day));

        // If the Label found is Empty Just add Lecture Data
        if (TheLabel.getText().isEmpty())
            TheLabel.setText(Module + "/" + Room);
        else // If the Label found is Not Empty add a \n then add Lecture Data
            TheLabel.setText(TheLabel.getText() + "\n" + Module  + "/" + Room);
    }

    // This Below method will find and return the Node "Label" inside the Grid Pane given row + col
    public Node getNodeByRowCol(int row, int col) {

        for (Node node : GridFullSchedule.getChildren())
            if (node != null && GridFullSchedule.getRowIndex(node) != null && GridFullSchedule.getColumnIndex(node) != null)
                if(node instanceof Label)
                    if (GridFullSchedule.getRowIndex(node) == row && GridFullSchedule.getColumnIndex(node) == col)
                        return node;
        return null;
    }

    private int GetColumnNumber(String Day) {
        switch (Day) {
            case "Monday" -> {return 1;}
            case "Tuesday" -> {return 2;}
            case "Wednesday" -> {return 3;}
            case "Thursday" -> {return 4;}
            case "Friday" -> {return 5;}
        }
        return 0;
    }

    private int GetRowNumber(String Time) {
        switch (Time) {
            case "09:00-10:00" -> {return 1;}
            case "10:00-11:00" -> {return 2;}
            case "11:00-12:00" -> {return 3;}
            case "12:00-13:00" -> {return 4;}
            case "13:00-14:00" -> {return 5;}
            case "14:00-15:00" -> {return 6;}
            case "15:00-16:00" -> {return 7;}
            case "16:00-17:00" -> {return 8;}
            case "17:00-18:00" -> {return 9;}
        }
        return 0;
    }


    public void ClearLectureScheduleGridPane() {
        for (Node node : GridFullSchedule.getChildren()) {

            if (node != null && GridFullSchedule.getRowIndex(node) != null && GridFullSchedule.getColumnIndex(node) != null)
                if (node instanceof Label)
                    if (GridFullSchedule.getRowIndex(node) > 0 && GridFullSchedule.getColumnIndex(node) > 0) { // Skip Header Row and Most Left Row
                        Label TheLabel = (Label) node; // Cast Current Node as Label
                        TheLabel.setText("");
                    }
        }
    }
}