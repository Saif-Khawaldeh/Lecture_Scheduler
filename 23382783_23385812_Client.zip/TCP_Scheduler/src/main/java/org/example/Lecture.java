// Lecture Model

package org.example;

import java.io.Serializable;

public class Lecture implements Serializable{

    private String day;
    private String time;
    private String moduleCode;
    private String professor;
    private String roomId;


    // Model Constructor
    public Lecture(String day, String time, String moduleCode, String professor, String roomId) {
        this.day = day;
        this.time = time;
        this.moduleCode = moduleCode;
        this.professor = professor;
        this.roomId = roomId;
    }

    // Model Getter methods
    public String getDay() {
        return day;
    }

    public String getTime() {
        return time;
    }

    public String getModuleCode() {
        return moduleCode;
    }

    public String getProfessor() {
        return professor;
    }

    public String getRoomId() {
        return roomId;
    }



    // Model Setter methods
    public void setDay(String day) {
        this.day = day;
    }

    public void setStartTime(String startTime) {
        this.time = startTime;
    }

    public void setModuleCode(String moduleCode) {this.moduleCode = moduleCode;}

    public void setProfessor(String professor) {this.professor = professor;}

    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }

}
