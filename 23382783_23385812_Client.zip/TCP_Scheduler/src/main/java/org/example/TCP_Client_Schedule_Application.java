package org.example;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
//Main Runnanble class

public class TCP_Client_Schedule_Application extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(TCP_Client_Schedule_Application.class.getResource("TCP_Client_Schedule_View.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Lectures Scheduler - Client Application");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}