// Lecture Controller

package org.example;

import java.io.Serializable;

public class LectureController implements Serializable{

    private Lecture model;
    private LectureView view;

    // Controller Constructor
    public LectureController(Lecture model, LectureView view){
        this.model = model;
        this.view=view;
    }

    // Controller Getter methods
    public String getDay() {
        return model.getDay();
    }

    public String getTime() {
        return model.getTime();
    }

    public String getModuleCode() {
        return model.getModuleCode();
    }

    public String getProfessor() { return model.getProfessor();}

    public String getRoomId() {
        return model.getRoomId();
    }

    public Lecture getLecture() {
        return model;
    }


    // Controller Setter methods

    public void setDay(String day) {model.setDay(day);}

    public void setStartTime(String startTime) {
        model.setStartTime(startTime);
    }

    public void setModuleCode(String moduleCode) {model.setModuleCode(moduleCode);}

    public void setProfessor(String professor) {model.setProfessor(professor);}

    public void setRoomId(String roomId) {
        model.setRoomId(roomId);
    }


    // Lecture Controller - Print Details // Through View
    public void printLectureDetails(){
        view.printLectureDetails(model.getDay(), model.getTime(), model.getModuleCode(), model.getProfessor(), model.getRoomId());
    }

}
