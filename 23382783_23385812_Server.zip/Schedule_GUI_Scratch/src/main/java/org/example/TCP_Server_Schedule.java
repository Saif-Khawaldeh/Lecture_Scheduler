package org.example;

import javafx.concurrent.Task;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;




public class TCP_Server_Schedule  {
    public static volatile boolean updateFlag = false;

    //refrence to HelloController  to call platform run later when adding or removing a lecture
    private static HelloController fxController;



    // Thread-safe lecture schedule
    static final List<LectureController> LectureSchedule = Collections.synchronizedList(new ArrayList<>());

    // Thread pool with 10 worker threads (adjust based on expected load)
    private static final ExecutorService threadPool = Executors.newFixedThreadPool(10);

    // Load sample data
    public static void loadDefaultLectures() {
        LectureSchedule.add(new LectureController(new Lecture("Monday", "13:00-14:00", "CS4076", "Abdul", "CSG001"), new LectureView()));
        LectureSchedule.add(new LectureController(new Lecture("Monday", "15:00-16:00", "CS4006", "Malachy", "CS1001"), new LectureView()));
        LectureSchedule.add(new LectureController(new Lecture("Tuesday", "13:00-14:00", "CS4076", "Abdul", "CSG001"), new LectureView()));
        LectureSchedule.add(new LectureController(new Lecture("Tuesday", "15:00-16:00", "CS4006", "Malachy", "CS1001"), new LectureView()));
        LectureSchedule.add(new LectureController(new Lecture("Thursday", "13:00-14:00", "CS4076", "Abdul", "CSG001"), new LectureView()));
        LectureSchedule.add(new LectureController(new Lecture("Friday", "15:00-16:00", "CS4006", "Malachy", "CS1001"), new LectureView()));

        System.out.println("printing lectures");
        PrintCurrentSchedule();
        System.out.println("");


    }

    public static void main(String[] args) {
        System.out.println("TCP running");
        loadDefaultLectures();
        //PrintCurrentSchedule();
        StartServer();
    }


    public static List<LectureController>getLectures(){
        return LectureSchedule;
    }

    private static void PrintCurrentSchedule() {
        for (LectureController lecture : LectureSchedule)
            lecture.printLectureDetails();
    }

    public static void StartServer() {
        try (ServerSocket serverSocket = new ServerSocket(22345)) {
            System.out.println("\nServer started. Waiting for clients...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("\nClient connected!");

                // Submit each new client to the thread pool
                threadPool.submit(new ClientHandler(clientSocket, LectureSchedule));
            }
        } catch (IOException ex) {
            System.out.println("Server error: " + ex.getMessage());
        } finally {
            gracefulShutdown(threadPool);
        }
    }

    private static void gracefulShutdown(ExecutorService threadPool) {
        System.out.println("\nInitiating graceful shutdown...");

        // Step 1: Disable new tasks
        threadPool.shutdown();

        try {
            // Step 2: Wait for existing tasks to finish
            if (!threadPool.awaitTermination(30, TimeUnit.SECONDS)) {
                // Step 3: Force shutdown if timeout reached
                System.err.println("Forcing shutdown of unfinished tasks");
                threadPool.shutdownNow();

                // Wait again for cancellation
                if (!threadPool.awaitTermination(30, TimeUnit.SECONDS)) {
                    System.err.println("Thread pool did not terminate");
                }
            }
        } catch (InterruptedException e) {
            // Re-cancel if current thread interrupted
            threadPool.shutdownNow();
            Thread.currentThread().interrupt(); // Preserve interrupt status
        }

        System.out.println("Shutdown complete");
    }
    static synchronized void AddNewLectureObject(LectureController lecture) {


        String DayToBeAdded = lecture.getDay();
        String TimeToBeAdded = lecture.getTime();
        String ModuleCodeToBeAdded = lecture.getModuleCode();
        String ProfessorToBeAdded = lecture.getProfessor();
        String RoomIdToBeAdded = lecture.getRoomId();
        // Check for time slot clash
        for(LectureController lec : LectureSchedule) {
            if(lec.getTime().equals(TimeToBeAdded) && lec.getDay().equals(DayToBeAdded)) {
                //return "LECTURE_RESERVED_SAME_TIME_SLOT";
                System.out.println("reserved time slot");
            }
        }

        // Check for room occupation
        for(LectureController lec : LectureSchedule) {
            if(lec.getRoomId().equals(RoomIdToBeAdded) && lec.getTime().equals(TimeToBeAdded) && lec.getDay().equals(DayToBeAdded)) {
                //return "ROOM_OCCUPIED";
                System.out.println("room occuipied");
            }
        }

        // Check for module time clash
        for(LectureController lec : LectureSchedule) {
            if(lec.getModuleCode().equals(ModuleCodeToBeAdded) && lec.getTime().equals(TimeToBeAdded) && lec.getDay().equals(DayToBeAdded)) {
               // return "MODULE_RESERVED_SAME_TIME_SLOT";
                System.out.println("module occuipied");
            }
        }

        // Check for maximum modules
        if (!IsTotalModulesMaxFive(ModuleCodeToBeAdded))
            System.out.println("max modules");
            //return "CANNOT_EXCEED_FIVE_MODULES";

        // Check for professor availability
        for(LectureController lec : LectureSchedule) {
            if(lec.getProfessor().equals(ProfessorToBeAdded) && lec.getTime().equals(TimeToBeAdded) && lec.getDay().equals(DayToBeAdded)) {
                //return "PROFESSOR_HAS_LECTURE_SAME_TIME_SLOT";
                System.out.println("professor occuipied");
            }
        }

        // If no clashes found, add the lecture
        System.out.println("adding Lecture ");
        LectureSchedule.add(new LectureController(new Lecture(DayToBeAdded, TimeToBeAdded, ModuleCodeToBeAdded, ProfessorToBeAdded, RoomIdToBeAdded), new LectureView()));
        System.out.println("Lecture added");


       // return "ADD_LECTURE_SUCCESS";

    }
    static synchronized String AddNewLecture(String Raw_Data) {
        // First parse the new Raw data and split into an Array by delimiter ","
        String[] dataArray = Raw_Data.split(",");

        String DayToBeAdded = dataArray[0];
        String TimeToBeAdded = dataArray[1];
        String ModuleCodeToBeAdded = dataArray[2];
        String ProfessorToBeAdded = dataArray[3];
        String RoomIdToBeAdded = dataArray[4];

        // Check for time slot clash
        for(LectureController lec : LectureSchedule) {
            if(lec.getTime().equals(TimeToBeAdded) && lec.getDay().equals(DayToBeAdded)) {
                return "LECTURE_RESERVED_SAME_TIME_SLOT";
            }
        }

        // Check for room occupation
        for(LectureController lec : LectureSchedule) {
            if(lec.getRoomId().equals(RoomIdToBeAdded) && lec.getTime().equals(TimeToBeAdded) && lec.getDay().equals(DayToBeAdded)) {
                return "ROOM_OCCUPIED";
            }
        }

        // Check for module time clash
        for(LectureController lec : LectureSchedule) {
            if(lec.getModuleCode().equals(ModuleCodeToBeAdded) && lec.getTime().equals(TimeToBeAdded) && lec.getDay().equals(DayToBeAdded)) {
                return "MODULE_RESERVED_SAME_TIME_SLOT";
            }
        }

        // Check for maximum modules
        if (!IsTotalModulesMaxFive(ModuleCodeToBeAdded))
            return "CANNOT_EXCEED_FIVE_MODULES";

        // Check for professor availability
        for(LectureController lec : LectureSchedule) {
            if(lec.getProfessor().equals(ProfessorToBeAdded) && lec.getTime().equals(TimeToBeAdded) && lec.getDay().equals(DayToBeAdded)) {
                return "PROFESSOR_HAS_LECTURE_SAME_TIME_SLOT";
            }
        }

        // If no clashes found, add the lecture
        System.out.println("adding Lecture ");
        LectureSchedule.add(new LectureController(new Lecture(DayToBeAdded, TimeToBeAdded, ModuleCodeToBeAdded, ProfessorToBeAdded, RoomIdToBeAdded), new LectureView()));
        System.out.println("Lecture added");
        //fxController.updateLecturesFromServer();   NOT  CORRECT APPROACH NOT WORKING  ITS SENDIGN null  TO CLIENT
        TCP_Server_Schedule.triggerUpdate();

        return "ADD_LECTURE_SUCCESS";
    }

    public static void triggerUpdate() {
        updateFlag = true;
    }
    static synchronized void RemoveLectureObject(LectureController lectureToRemove) {
        String DayToBeDeleted = lectureToRemove.getDay();
        String TimeToBeDeleted = lectureToRemove.getTime();
        String ModuleCodeToBeDeleted = lectureToRemove.getModuleCode();
        String ProfessorToBeDeleted = lectureToRemove.getProfessor();
        String RoomIdToBeDeleted = lectureToRemove.getRoomId();

        // Find and remove the matching lecture
        LectureController FoundLecture = null;
        for (LectureController lec : LectureSchedule) {
            if (lec.getDay().equals(DayToBeDeleted) &&
                    lec.getTime().equals(TimeToBeDeleted) &&
                    lec.getModuleCode().equals(ModuleCodeToBeDeleted) &&
                    lec.getProfessor().equals(ProfessorToBeDeleted) &&
                    lec.getRoomId().equals(RoomIdToBeDeleted)) {
                FoundLecture = lec;
                break;
            }
        }

        if (FoundLecture != null) {
            LectureSchedule.remove(FoundLecture);
            System.out.println("lecture removed");
            //TCP_Server_Schedule.triggerUpdate();
            //return "REMOVE_LECTURE_SUCCESS" + "," + DayToBeDeleted + "," + TimeToBeDeleted + "," + RoomIdToBeDeleted;
        } else {
            System.out.println("lecture not found");
            //return "LECTURE_NOT_FOUND";
        }

    }

    static synchronized String RemoveLecture(String Raw_Data) {
        // First parse the new Raw data and split into an Array by delimiter ","
        String[] dataArray = Raw_Data.split(",");

        String DayToBeDeleted = dataArray[0];
        String TimeToBeDeleted = dataArray[1];
        String ModuleCodeToBeDeleted = dataArray[2];
        String ProfessorToBeDeleted = dataArray[3];
        String RoomIdToBeDeleted = dataArray[4];

        // Find the lecture to remove
        LectureController FoundLecture = null;
        for(LectureController lec : LectureSchedule) {
            if(lec.getDay().equals(DayToBeDeleted) &&
                    lec.getTime().equals(TimeToBeDeleted) &&
                    lec.getModuleCode().equals(ModuleCodeToBeDeleted) &&
                    lec.getProfessor().equals(ProfessorToBeDeleted) &&
                    lec.getRoomId().equals(RoomIdToBeDeleted)) {
                FoundLecture = lec;
                break;
            }
        }

        if (FoundLecture != null) {
            LectureSchedule.remove(FoundLecture);
            TCP_Server_Schedule.triggerUpdate();
            return "REMOVE_LECTURE_SUCCESS" + "," + DayToBeDeleted + "," + TimeToBeDeleted + "," + RoomIdToBeDeleted;
        }
        else {
            return "LECTURE_NOT_FOUND";
        }


    }
    private static boolean IsTotalModulesMaxFive(String ModuleCodeToBeAdded) {
        // Temporary Array to have Modules with no duplications
        ArrayList<String> CurrentModules = new ArrayList<>();

        for (LectureController lec : LectureSchedule) {
            if (!CurrentModules.contains(lec.getModuleCode())) {
                CurrentModules.add(lec.getModuleCode());
            }
        }

        if (CurrentModules.contains(ModuleCodeToBeAdded)) {
            return true; // This is an Existing Module - Allow Adding
        } else {
            return CurrentModules.size() < 5; // This is a New Module - Check Total below 5 Modules
        }
    }



    static synchronized String EarlyLecture(){
        //create 5 threads  one for each day of the week
        // each one checks how many lectures there are in said day
        //each one takes the first lecture of the day and pushes it to the first available time slot and vice versa
        System.out.println("early lectures triggered");

        // Names for the threads based on days of the week
        Task<Void> task = new Task<>() {

            @Override
            protected Void call() throws Exception {
                String[] daysOfWeek = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
                Thread[] myThreads = new Thread[5];
                // Initialize and start 5 threads, each representing a day of the week
                for (int i = 0; i < 5; i++) {
                    final String day = daysOfWeek[i]; // Day of the week for this thread

                    // Create a thread for each day
                    myThreads[i] = new Thread(() -> {
                        dayTask(day);
                    });

                    // Set the thread's name to the corresponding day of the week
                    myThreads[i].setName(day);


                    // Start the thread
                    myThreads[i].start();
                }
                PrintCurrentSchedule();

                return null;
            }
        };

            // Start the task in a background thread
            Thread backgroundThread = new Thread(task);
            backgroundThread.setDaemon(true);
            backgroundThread.start();
            //triggerUpdate();

            return "EARLY_LECTURE_STARTED";



    }
    static void dayTask(String Day) {

        //check array list for all instances of lectures in this day
        //create array of time slots 9 to 10 .......
        //loop through array list and addLecture() to the first possible lect time
        // Define the list of available hourly time slots (9 AM to 5 PM)
        String[] timeSlots = {
                "09:00-10:00", "10:00-11:00", "11:00-12:00",
                "12:00-13:00", "13:00-14:00", "14:00-15:00",
                "15:00-16:00", "16:00-17:00", "17:00-18:00"
        };
        int timeIndex =0;



        // Extract all lectures for the specified day
        List<LectureController> dayLectures = new ArrayList<>();
        synchronized (LectureSchedule) {
            for (LectureController lec : LectureSchedule) {
                if (lec.getDay().equals(Day)) {
                    dayLectures.add(lec);


                }else {
                    System.out.println(lec.getDay() + " " + Day + " " + lec.getDay().length() + " " + Day.length());

                }
            }

            //to show off ealry lectures ffeature working
            System.out.println("today is " + Day);
            System.out.println("-------------DAY LECTURES------------------");
            for (LectureController lecture : dayLectures)
                lecture.printLectureDetails();
            System.out.println("--------------END-----------------");

            LectureSchedule.removeAll(dayLectures);
            System.out.println("------------------NORMAL LECT-------------");
            PrintCurrentSchedule();
            System.out.println("---------------END----------------");


            for (LectureController lec : dayLectures) {
                if (timeIndex < timeSlots.length) {
                    lec.setStartTime(timeSlots[timeIndex]);
                    AddNewLectureObject(lec);
                 //   LectureSchedule.add(new LectureController(new Lecture(DayToBeAdded, TimeToBeAdded, ModuleCodeToBeAdded, ProfessorToBeAdded, RoomIdToBeAdded), new LectureView()));

                    timeIndex++;
                } else {
                    // No more time slots available
                    break;
                }
            }


        }


    }





}