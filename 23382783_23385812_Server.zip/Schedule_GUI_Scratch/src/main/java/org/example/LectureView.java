// Lecture View

package org.example;

import java.io.Serializable;

public class LectureView implements Serializable{

    public void printLectureDetails(String day, String time, String moduleCode, String professor, String roomId){

        System.out.println("Day:" + day + ", Time:" + time + ", Module: " + moduleCode + ", Professor:" + professor + ", Room:" + roomId);

    }
}
