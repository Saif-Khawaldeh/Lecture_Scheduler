package org.example;

import java.io.*;
import java.net.Socket;
import java.util.List;

public class ClientHandler implements Runnable {
    private final Socket clientSocket;
    private final List<LectureController> lectureSchedule;

    public ClientHandler(Socket socket, List<LectureController> schedule) {
        this.clientSocket = socket;
        this.lectureSchedule = schedule; // Shared thread-safe list
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(
                new InputStreamReader(clientSocket.getInputStream()));
             PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {

            System.out.println("Thread " + Thread.currentThread().getId() + " handling client " + clientSocket.getRemoteSocketAddress());

            String clientMessage;
            while ((clientMessage = in.readLine()) != null) {
                System.out.println("Received: " + clientMessage);
                processMessage(clientMessage, out);
            }

        } catch (IOException e) {
            System.err.println("Client error: " + e.getMessage());
        } finally {
            closeClientSocket();
        }
    }

    private void processMessage(String message, PrintWriter out) {
        try {
            if (message.startsWith("ADD LECTURE")) {
                handleAddLecture(message.substring(12), out);
            }
            else if (message.startsWith("REMOVE LECTURE")) {
                handleRemoveLecture(message.substring(15), out);
            }
            else if (message.equals("DISPLAY SCHEDULE")) {
                sendSchedule(out);
            }
            else if (message.equals("STOP")) {
                out.println("TERMINATE");
                throw new IOException("Client initiated disconnect");
            } else if (message.equals("EARLY LECTURES")) {
                handleEarlyLectures();


            } else {
                throw new IncorrectActionException("SERVICE_NOT_FOUND");
            }
        } catch (IncorrectActionException | IOException e) {
            out.println("ERROR: " + e.getMessage());
            System.err.println("Processing error: " + e.getMessage());
        }
    }

    private void handleAddLecture(String data, PrintWriter out) {
        String response = TCP_Server_Schedule.AddNewLecture(data);
        out.println(response);
        System.out.println("Add Lecture Result: " + response);
    }

    private void handleRemoveLecture(String data, PrintWriter out) {
        String response = TCP_Server_Schedule.RemoveLecture(data);
        out.println(response);
        System.out.println("Remove Lecture Result: " + response);
    }
    private void handleEarlyLectures() {
        TCP_Server_Schedule.EarlyLecture();
    }

    private void sendSchedule(PrintWriter out) {
        try {
            ObjectOutputStream objOut = new ObjectOutputStream(clientSocket.getOutputStream());
            objOut.writeObject(lectureSchedule);
            //out.println(lectureSchedule);
            System.out.println("Sent schedule to client");
        } catch (IOException e) {
            System.err.println("Failed to send schedule: " + e.getMessage());
            out.println("ERROR_SENDING_SCHEDULE");
        }
    }

    private void closeClientSocket() {
        try {
            if (clientSocket != null && !clientSocket.isClosed()) {
                clientSocket.close();
                System.out.println("Closed connection for " + clientSocket.getRemoteSocketAddress());
            }
        } catch (IOException e) {
            System.err.println("Error closing socket: " + e.getMessage());
        }
    }
}