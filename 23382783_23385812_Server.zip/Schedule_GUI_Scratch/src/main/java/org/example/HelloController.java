package org.example;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.text.TextAlignment;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    private static final ArrayList<LectureController> UILectureSchedule = new ArrayList<>();

    private ObservableList<LectureController> getServerLectureSchedule() {
        return FXCollections.observableArrayList(TCP_Server_Schedule.LectureSchedule);
    }


    @FXML
    private GridPane GridFullSchedule;

    @FXML
    private TableView<Lecture> LecturesScheduleTableView;
    @FXML
    private TableColumn<Lecture, String> DayColumn;
    @FXML
    private TableColumn<Lecture, String> TimeColumn;
    @FXML
    private TableColumn<Lecture, String> ModuleColumn;
    @FXML
    private TableColumn<Lecture, String> ProfessorColumn;
    @FXML
    private TableColumn<Lecture, String> RoomColumn;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        // On Window initialize, Prepare the Columns in Table View
        DayColumn.setCellValueFactory(new PropertyValueFactory<Lecture, String>("day"));
        TimeColumn.setCellValueFactory(new PropertyValueFactory<Lecture, String>("time"));
        ModuleColumn.setCellValueFactory(new PropertyValueFactory<Lecture, String>("moduleCode"));
        ProfessorColumn.setCellValueFactory(new PropertyValueFactory<Lecture, String>("professor"));
        RoomColumn.setCellValueFactory(new PropertyValueFactory<Lecture, String>("roomId"));

        //on intiliaze prepares grid labels
        PrepareGridPaneLabels();
        TCP_Server_Schedule.loadDefaultLectures();
        updateLecturesFromServer();// GUI
        constantRefresh();

    }

    private void constantRefresh() {
        Task<Void> flagWatcher = new Task<>() {
            @Override
            protected Void call() throws Exception {
                while (true) {
                    if (true) {
                        TCP_Server_Schedule.updateFlag = false;
                        updateLecturesFromServer();
                    }
                    Thread.sleep(1000); // check every 1 sec
                }
            }
        };
        Thread thread = new Thread(flagWatcher);
        thread.setDaemon(true); // ensures it closes when the app closes
        thread.start();
    }


    public  void updateLecturesFromServer() {
        // to be Used  once a new lecture is added  or removed
        // Run on JavaFX Application Thread
        Platform.runLater(() -> {
            // Clear existing lectures
            UILectureSchedule.clear();


            //TCP_Server_Schedule.loadDefaultLectures();
            // Add all lectures from server
            UILectureSchedule.addAll(TCP_Server_Schedule.getLectures());


            // Refresh the grid display
            LoadLectureScheduleIntoGridPane();

            // If using TableView
            try {
                RefreshLectureTableViewFromServer();
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        });
    }



    public void PrepareGridPaneLabels() {

        for (int colIndex = 1; colIndex <= 5; colIndex++) {
            for (int rowIndex = 1; rowIndex <= 9; rowIndex++) {
                Label lbl = new Label();
                lbl.setText(""); //Start with Empty Labels

                lbl.setTextAlignment(TextAlignment.CENTER);
                lbl.setAlignment(Pos.CENTER);
                GridPane.setValignment(lbl, VPos.CENTER);
                GridPane.setHalignment(lbl, HPos.CENTER);

                GridFullSchedule.add(lbl, colIndex, rowIndex);
            }

        }

    }

    // to be used every time change is made
    public void LoadLectureScheduleIntoGridPane(){

        ClearLectureScheduleGridPane();

        for(LectureController lecture : UILectureSchedule)
            SetLectureInCorrectPosition(lecture.getDay(),lecture.getTime(),lecture.getModuleCode(),lecture.getProfessor(),lecture.getRoomId());
    }

    public void RefreshLectureTableViewFromServer() throws IOException, ClassNotFoundException {

        // First Get Latest Schedule from Server and update local ArrayList
        //UpdateLocalArrayListFromServer();

        // Now Load Table View Data from Updated Local Lectures ArrayList
        LecturesScheduleTableView.getItems().clear();
        for (LectureController Lec : UILectureSchedule) {
            LecturesScheduleTableView.getItems().add(Lec.getLecture());
        }
    }


    private void SetLectureInCorrectPosition(String Day, String Time, String Module, String Professor, String Room) {

        // First Search all Grid Pane children and find the exact Label by (Day/Time)
        Label TheLabel = (Label)getNodeByRowCol(GetRowNumber(Time),GetColumnNumber(Day));

        // If the Label found is Empty Just add Lecture Data
        if (TheLabel.getText().isEmpty())
            TheLabel.setText(Module + "/" + Room);
        else // If the Label found is Not Empty add a \n then add Lecture Data
            TheLabel.setText(TheLabel.getText() + "\n" + Module  + "/" + Room);
    }

    public void ClearLectureScheduleGridPane() {
        for (Node node : GridFullSchedule.getChildren()) {

            if (node != null && GridFullSchedule.getRowIndex(node) != null && GridFullSchedule.getColumnIndex(node) != null)
                if (node instanceof Label)
                    if (GridFullSchedule.getRowIndex(node) > 0 && GridFullSchedule.getColumnIndex(node) > 0) { // Skip Header Row and Most Left Row
                        Label TheLabel = (Label) node; // Cast Current Node as Label
                        TheLabel.setText("");
                    }
        }
    }
    // This Below method will find and return the Node "Label" inside the Grid Pane given row + col
    public Node getNodeByRowCol(int row, int col) {

        for (Node node : GridFullSchedule.getChildren())
            if (node != null && GridFullSchedule.getRowIndex(node) != null && GridFullSchedule.getColumnIndex(node) != null)
                if(node instanceof Label)
                    if (GridFullSchedule.getRowIndex(node) == row && GridFullSchedule.getColumnIndex(node) == col)
                        return node;
        return null;
    }

    private int GetColumnNumber(String Day) {
        switch (Day) {
            case "Monday" -> {return 1;}
            case "Tuesday" -> {return 2;}
            case "Wednesday" -> {return 3;}
            case "Thursday" -> {return 4;}
            case "Friday" -> {return 5;}
        }
        return 0;
    }

    private int GetRowNumber(String Time) {
        switch (Time) {
            case "09:00-10:00" -> {return 1;}
            case "10:00-11:00" -> {return 2;}
            case "11:00-12:00" -> {return 3;}
            case "12:00-13:00" -> {return 4;}
            case "13:00-14:00" -> {return 5;}
            case "14:00-15:00" -> {return 6;}
            case "15:00-16:00" -> {return 7;}
            case "16:00-17:00" -> {return 8;}
            case "17:00-18:00" -> {return 9;}
        }
        return 0;
    }


}