package org.example;


public class IncorrectActionException extends Exception
{
    // Parameterless Constructor
    public IncorrectActionException() {}

    // Constructor that accepts a message
    public IncorrectActionException(String message)
    {
        super(message);
    }
}